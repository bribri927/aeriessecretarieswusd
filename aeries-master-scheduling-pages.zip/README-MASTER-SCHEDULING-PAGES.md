# Master Scheduling Expansion Pages

Upload these files to the same GitHub repo / Netlify site. Keep existing files and add these.

New pages:
- master-scheduling-center.html
- scheduling-start-here.html
- scheduling-elementary.html
- scheduling-middle-school.html
- scheduling-high-school.html
- scheduling-flex-models.html
- scheduling-troubleshooting.html
- scheduling-checklist.html
- scheduling-queries.html
- scheduling-assistant.html
- Master_Scheduling_Playbook_V1.pdf

Recommended Google Sites links can point directly to these Netlify URLs.
